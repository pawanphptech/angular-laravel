
<!--  Forms Validations Plugin -->
<script src="backend/js/jquery.validate.min.js"></script>

<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
<script src="backend/js/moment.min.js"></script>

<!--  Date Time Picker Plugin is included in this js file -->
<script src="backend/js/bootstrap-datetimepicker.js"></script>

<!--  Select Picker Plugin -->
<script src="backend/js/bootstrap-selectpicker.js"></script>

<!--  Checkbox, Radio, Switch and Tags Input Plugins -->
<script src="backend/js/bootstrap-checkbox-radio-switch-tags.js"></script>

<!-- Circle Percentage-chart -->
<script src="backend/js/jquery.easypiechart.min.js"></script>

<!--  Charts Plugin -->
<script src="backend/js/chartist.min.js"></script>

<!--  Notifications Plugin    -->
<script src="backend/js/bootstrap-notify.js"></script>

<!-- Sweet Alert 2 plugin -->
<script src="backend/js/sweetalert2.js"></script>

<!-- Vector Map plugin -->
<script src="backend/js/jquery-jvectormap.js"></script>

<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js"></script>

<!-- Wizard Plugin    -->
<script src="backend/js/jquery.bootstrap.wizard.min.js"></script>

<!--  Bootstrap Table Plugin    -->
<script src="backend/js/bootstrap-table.js"></script>

<!--  Full Calendar Plugin    -->
<script src="backend/js/fullcalendar.min.js"></script>

<!-- Paper Dashboard PRO Core javascript and methods for Demo purpose -->
<script src="backend/js/paper-dashboard.js"></script>

<!-- Paper Dashboard PRO DEMO methods, don't include it in your project! -->
<script src="backend/js/app.js"></script>
